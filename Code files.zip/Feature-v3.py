import pandas as pd
from plotly.offline import plot
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("yelp_academic_dataset_business_1.csv")


states = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DC", "DE", "FL", "GA", 
          "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", 
          "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", 
          "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", 
          "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"]


##########   Feature 1 - Chain of restuarants  ##############################

chain = input("Enter resturant chain to find which state has the highest rating: ")
while chain.upper() != "N":
    df1 = df[df['name'].str.contains(chain, case=False)]
    if df1.empty:
        print("Not Found!")
    else:
        df1 = df1[df1['state'].isin(states)]
        df1 = df1.groupby(by=['name','state'])[['stars']].mean().reset_index()
        df1 = df1.sort_values(by='stars',ascending=True)
        g = sns.barplot(x='state',y="stars",data=df1,ci =None)
        plt.show()
        chain =input("Enter N to exit or enter restuarant chain: ")
        

##########  Feature 2 - Avg rating for states  ##############################

print("\n","*"*10," Average Restuarant Rating for each state ", "*"*10)

cscl = [[0.0, 'rgb(242,240,247)'],[0.2, 'rgb(218,218,235)'],[0.4, 'rgb(188,189,220)'],\
            [0.6, 'rgb(158,154,200)'],[0.8, 'rgb(117,107,177)'],[1.0, 'rgb(84,39,143)']]


df=df.groupby(by='state')[['stars']].mean()
df=df.reset_index()

data = [ dict(
        type='choropleth',
        colorscale = cscl,
        autocolorscale = False,
        locations = df['state'],
        z = df['stars'].astype(float),
        locationmode = 'USA-states',
        marker = dict(
            line = dict (color = 'rgb(255,255,255)',width = 2)),
        colorbar = dict(title = "Customer Rating")    ) ]

layout = dict(
        title = 'Average Restuarant rating by state',
        geo = dict(
            scope='usa',
            projection=dict( type='albers usa' ),
            showlakes = True,
            lakecolor = 'rgb(255, 255, 255)',
        ),    )

fig = dict(data=data, layout=layout)

url = plot(fig, filename='Avg-rating.html')


