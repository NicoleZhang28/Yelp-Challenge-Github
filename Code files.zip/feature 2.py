import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np 
import pandas as pd 


#%matplotlib inline

business = pd.read_csv('yelp_academic_dataset_business.csv')

# Top 30 most reviewed businesses
print("===================Most Reviewed Businesses (Top 30) ====================")
top30= business[['name', 'review_count', 'city', 'stars']].sort_values(ascending=False, by="review_count")[0:30]
print(top30)


# cities with most businesses
print("===================Cities with Most Businesses ====================")
city_business_counts = business[['city', 'business_id']].groupby(['city'])\
['business_id'].agg('count').sort_values(ascending=False)

city_business_counts = pd.DataFrame(data=city_business_counts)

city_business_counts.rename(columns={'business_id' : 'number_of_businesses'}, inplace=True)

city_business_counts[0:30].sort_values(ascending=False, by="number_of_businesses")\
.plot(kind='barh', stacked=False, figsize=[10,10], colormap='winter')
plt.title('Top 30 cities by number of businesses listed')


# Amalyzing tip data

from sklearn.feature_extraction.text import CountVectorizer # to convert a collection of text documents to a matrix of token counts
tip = pd.read_csv('yelp_academic_dataset_tip.csv')

print('=======Analyze Pre-Selected Keywords in Yelp Tip Data =======')
selected_words = ['wait', 'awesome', 'great', 'fantastic', 'amazing', 'love', 'horrible', 'bad', 'terrible', 
                  'awful', 'wow', 'hate'] # specifying the vocabs
print (selected_words)

vectorizer = CountVectorizer(vocabulary=selected_words, lowercase=False)
#corpus = ['This is the first document.','This is the second second document.']
#print corpus
selected_word_count = vectorizer.fit_transform(tip['text'].values.astype('U'))
vectorizer.get_feature_names()

word_count_array = selected_word_count.toarray()


wc = pd.DataFrame(index=vectorizer.get_feature_names(), \
                    data=word_count_array.sum(axis=0)).rename(columns={0: 'Count'})

wc.plot(kind='bar', stacked=False, figsize=[7,7], colormap='winter')

# Check the selected words occurance per business

business_name = input('Enter your business name:')

name_to_id = business.loc[business['name'] == business_name, 'business_id',]
print(name_to_id)
b_id = input('Please enter your businessid based on the choices above:')

#bname = business[business.name== business_name]

tip_check = tip.loc[tip['business_id'] == b_id]

tip_check_selected_word_count = \
vectorizer.fit_transform(tip_check['text'].values.astype('U'))

word_count_array = tip_check_selected_word_count.toarray()
tip_check_result = pd.DataFrame(index=vectorizer.get_feature_names(), \
                    data=word_count_array.sum(axis=0)).rename(columns={0: 'Count'})
print(tip_check_result)
tip_check_result.plot(kind='bar', stacked=False, figsize=[7,7], colormap='summer')



