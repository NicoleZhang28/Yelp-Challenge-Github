import pandas as pd
from geopy.geocoders import Nominatim
from geopy.distance import geodesic


#DATA LOAD CODE: load data, drop columns that are not being used, rename columns
df = pd.read_csv("yelp_academic_dataset_business.csv")
df = df[df['categories'].str.contains("Food|Restaurants")==True]
df = df[df['is_open'] == 1]
df.reset_index()
df.to_csv(path_or_buf = "yelp_academic_dataset_business_1.csv")
df = df.drop(columns=['AgesAllowed','GoodForDancing','CoatCheck','RestaurantsCounterService', \
                      'ByAppointmentOnly','BusinessAcceptsBitcoin','HairSpecializesIn','AcceptsInsurance', \
                      'hours.Thursday','hours.Wednesday','hours.Tuesday','hours.Sunday','Open24Hours', \
                      'hours.Monday','business_id','hours.Friday','Ambience','RestaurantsTableService', \
                      'Smoking','hours.Saturday','BYOBCorkage'])
df= df.rename(index=str, columns={"BikeParking":"Bike Parking", "OutdoorSeating":"Outdoor Seating", \
                                      "RestaurantsGoodForGroups":"Groups","GoodForKids":"Kids", \
                                      "RestaurantsDelivery":"Delivery","GoodForKids":"Kids", \
                                      "RestaurantsTakeOut":"Take Out","DogsAllowed":"Dogs Allowed", \
                                      "HasTV":"TV","WheelchairAccessible":"Wheelchair Accessible", \
                                      "DriveThru":"Drive Thru","HappyHour":"Happy Hour"})

df = df.replace(['beer_and_wine','full_bar','free','paid'],True) #converts values in alcohol and wifi to True/False
df.loc[df['Music'].str.contains('True',na=False), 'Music'] = True #converts values in music to True/False

#GUI CODE STARTS BELOW:
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
import PIL
from PIL import Image, ImageTk


window = tk.Tk()
window.title("Yelp Restaurant Finder")
window.geometry('550x600')

image = PIL.Image.open('yelp.png')
display = ImageTk.PhotoImage(image)
label = tk.Label(window, image=display)
#Label.image = display
label.pack()

lbl = tk.Label(window, text="Welcome! Let us help you find a restaurant of your liking!", font=("Helvetica Bold", 10))
#lbl.configure(foreground='#FFFFFF')
lbl.pack()

#Feature 1 drop down box
lbl = tk.Label(window, text="\n What is your first desired feature?", font=("Helvetica", 8))
lbl.pack()
feat1 = ttk.Combobox(window) 
feat1['values']= ('Alcohol','Bike Parking','BYOB','Outdoor Seating','Groups', 'Kids','Delivery', \
                 'Take Out', 'Dogs Allowed', 'TV', 'Music', 'Wheelchair Accessible','Drive Thru', \
                 'Caters','Corkage','WiFi','Happy Hour')
feat1.pack()

#Feature 2 drop down box
lbl = tk.Label(window, text="What is your second desired feature?", font=("Helvetica", 8))
lbl.pack()
feat2 = ttk.Combobox(window) 
feat2['values']= ('Alcohol','Bike Parking','BYOB','Outdoor Seating','Groups', 'Kids','Delivery', \
                 'Take Out', 'Dogs Allowed', 'TV', 'Music', 'Wheelchair Accessible','Drive Thru', \
                 'Caters','Corkage','WiFi','Happy Hour')
feat2.pack()

#Feature 3 drop down box
lbl = tk.Label(window, text="What is your third desired feature?", font=("Helvetica", 8))
lbl.pack()
feat3 = ttk.Combobox(window) 
feat3['values']= ('Alcohol','Bike Parking','BYOB','Outdoor Seating','Groups', 'Kids','Delivery', \
                 'Take Out', 'Dogs Allowed', 'TV', 'Music', 'Wheelchair Accessible','Drive Thru', \
                 'Caters','Corkage','WiFi','Happy Hour')
feat3.pack()

#User's location text box
lbl = tk.Label(window, text="Enter your address and state:", font=("Helvetica", 8))
lbl.pack()
e = tk.Entry(window,width=25)
e.pack()

#Program executed when "Find Restaurants" button is clicked
def clicked():
    f1 = feat1.get()
    f2 = feat2.get()
    f3 = feat3.get()
    addy = e.get()
    
    #filters dataframe for user's 3 selected features from drop down boxes
    filt1 = df[df[f1] == True]
    filt2 = filt1[filt1[f2] == True]
    filt3 = filt2[filt2[f3] == True]
    filt3 = filt3.reset_index(drop=True)
    
    #GeoLocation code starts here
    geolocator = Nominatim(timeout=None)
    location = geolocator.geocode(addy) #takes user's entered address
    userLoc = pd.DataFrame({'userlong': location.longitude, 'userlat': location.latitude}, index=[0])
    
    #Merges filtered df of user's features with user's location
    df_all = pd.merge(filt3.assign(key=0), userLoc.assign(key=0), on='key').drop('key', axis=1)
    df_all['Distance'] = df_all.apply((lambda row: geodesic((row['latitude'], row['longitude']), \
          (row['userlat'], row['userlong'])).miles),axis=1) #calculates distance btwn user and restaurant location
    
    """
    Since the userRecs dataframe is sorted by Distance, you can access the top 5 restaurants by calling the location
    of the restaurant by index (#'s 0 - 4). For example, to access the long and lat of the 1st recommendation, the code
    will be: userRecs.iloc[0]['latitude'] and userRecs.iloc[0]['longitude']
    
    If you want to access the user's, it is stored in every row of the df_all dataframe. For example, the code will be:
    df_all.iloc[0]['userlat'] and df_all.iloc[0]['userlong']
    """
    #creates list of recommendations that is sorted by Distance
    userRecs = df_all.sort_values(by=['Distance'])
    userRecs = userRecs.reset_index(drop=True)
    userRecs = userRecs[['name','address','latitude','longitude']]
    #creates a string of top 5 recommendations (name + address) and prints to textbox
    a = userRecs.iloc[0]['name'] + ", " + userRecs.iloc[0]['address'] + '\n' + \
    userRecs.iloc[1]['name'] + ", " + userRecs.iloc[1]['address'] + '\n' + \
    userRecs.iloc[2]['name'] + ", " + userRecs.iloc[2]['address'] + '\n' + \
    userRecs.iloc[3]['name'] + ", " + userRecs.iloc[3]['address'] + '\n' + \
    userRecs.iloc[4]['name'] + ", " + userRecs.iloc[4]['address']
    recs.insert(tk.INSERT, a)

btn = tk.Button(window, text="Find Restaurants", command=clicked)
btn.pack()



#Restaurant Recs
lbl = tk.Label(window, text="\n Restaurant Recomendations", font=("Helvetica Italics", 10))
lbl.pack()
recs = scrolledtext.ScrolledText(window,width=60,height=10)
recs.pack()

#reset button
def reset():
    recs.delete(1.0,tk.END)
    feat1.set('')
    feat2.set('')
    feat3.set('')
    e.delete(0,tk.END)
    
btn1 = tk.Button(window, text="Reset", command=reset)
btn1.pack()


window.mainloop()