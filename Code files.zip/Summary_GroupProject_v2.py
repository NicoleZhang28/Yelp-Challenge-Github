
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("yelp_academic_dataset_business.csv")
df.dropna(axis=0,subset=['business_id','RestaurantsPriceRange2','name', 'city','address','review_count','postal_code','stars'], inplace=True)
df.reset_index()

#Summary_Feature 1

total_resturant = df.name.count()
print("===================SUMMARY====================")


#The Original Data Set
print("The original dataset info: ")
df.info()

print("\n1.Based on our interests, we're analyzing resturants from",  total_resturant, "businesses in total across North America")

df = df.rename(columns = {'name': 'business'})


df1 = df.groupby(by = 'city').count()
df1 = df1.reset_index()


df2 = df.groupby(by= 'state').count()
df2 = df2.reset_index()

df1 = df1[['city','business']]

total_cities = df1.city.count()
total_states = df2.state.count()


print("\n2.The toal number of cities are: ", total_cities)

print("\n3.The toal number of States are: ", total_states)

print("\n4.The number of businesses in each city is: ")
print(df1)



#Summary_Feature 2

df = df[df['categories'].str.contains("Food|Restaurants")==True]
post = ''
print("\n5.This feature is to help you find out the best resturants in your area")
while post != "EXIT":
    
    post = input("What's your postal code (Type 'EXIT' to exit): ")  
        
    df2 = df.loc[df['postal_code'] == post]
    df2 = df2.rename(columns = {'business': 'resturant'})


#print(df2)
    df2 = df2[['postal_code','resturant','RestaurantsReservations','RestaurantsPriceRange2','review_count','stars']]
    df2 = df2.reset_index()
    df2 = df2.sort_values(by = ['stars', 'review_count'], ascending = [False, False])
    df2 = df2.head(5)
    
    if post == "EXIT":
        break
    if df2.empty:
        print("Zip code not present!!")
    else:
        print("The top five resturants in your region are:")
        print(df2['resturant'])
    
        df2.plot(x = 'resturant', y = 'stars')
        plt.xticks(rotation=90)
        df2.plot(x = 'resturant', y = 'review_count')
        plt.xticks(rotation=90)
        plt.show()


print ("\nThanks for using! Let's look at other features!")    
