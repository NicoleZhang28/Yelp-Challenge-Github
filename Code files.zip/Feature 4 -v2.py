import pandas as pd

df = pd.read_csv("yelp_academic_dataset_business.csv")
df.dropna(axis=0,subset=['business_id','RestaurantsPriceRange2'], inplace=True )
df.reset_index()

states = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DC", "DE", "FL", "GA", 
          "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", 
          "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", 
          "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", 
          "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"]

#######################   Feature 4  #################################

from difflib import SequenceMatcher
def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

udf = pd.read_csv("user_visit_data.csv")
udf.reset_index()

user = input('user name is: ' )
udf = udf[udf['user name'] == user]
uid = udf['visit business id ']
sdf = df
totalscore = []
sdfindex = []

for i in range(len(uid)):
    target = df[df['business_id'] == uid.iloc[i] ]
    sdf = sdf[sdf['business_id'] != uid.iloc[i] ]
    data = pd.DataFrame(target)
    #print(i, target)
# filter similardf by using same state and city a user is in 
    sdf = sdf[sdf['city'] == udf['city'].iloc[0] ]
    sdf = sdf[ sdf['state'] == udf['state'].iloc[0]]
###### the similarity of categories wights 40%, the price rage weights30%, the attribut weights 30$) 
    for t in  range(len(target)):
         for s in range(len(sdf)):
           # print(sdf.iloc[s]['attributes'])
            cata = similar(str(sdf.iloc[s]['categories']), str(target.iloc[t]['categories']))
            attribute = similar(str(sdf.iloc[s]['attributes']), str(target.iloc[t]['attributes']))
            price = similar(str(sdf.iloc[s]['RestaurantsPriceRange2']), str(target.iloc[t]['RestaurantsPriceRange2']))
            total = cata* 0.40 + attribute * 0.30 + price *0.30 
            totalscore.append(total)
            sdfindex.append(s)
         max_value = max(totalscore)
         max_index = totalscore.index(max_value)
         sindex = sdfindex[max_index]
         print(udf.iloc[i]['date'])
         print("Hi " + str(user)  + ", it is the time to enjoy the life!  " )
         print("We notice you have been to " + str(target.iloc[t]['name']) + " recently. Would you like to try "   
              + str( sdf.iloc[sindex]['name'])+ "? It provides "  + str( sdf.iloc[sindex]['categories'] ))
         print("                                                                     ")
